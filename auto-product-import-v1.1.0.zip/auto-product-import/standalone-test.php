<?php
/**
 * Standalone test script for Auto Product Import image extraction
 * This script doesn't require a WordPress database connection
 */

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Define constants needed by the plugin
define('AUTO_PRODUCT_IMPORT_PLUGIN_URL', '');
define('AUTO_PRODUCT_IMPORT_PLUGIN_DIR', dirname(__FILE__) . '/');
define('AUTO_PRODUCT_IMPORT_VERSION', '1.0.0');

// Define WordPress functions needed by the plugin
if (!function_exists('add_filter')) {
    function add_filter($hook, $callback) {
        global $filters;
        $filters[$hook][] = $callback;
    }
}

if (!function_exists('apply_filters')) {
    function apply_filters($hook, $value) {
        global $filters;
        if (isset($filters[$hook])) {
            foreach ($filters[$hook] as $callback) {
                $value = call_user_func($callback, $value);
            }
        }
        return $value;
    }
}

if (!function_exists('__return_true')) {
    function __return_true() {
        return true;
    }
}

// Initialize global filters array
global $filters;
$filters = array();

// Force debug mode on
add_filter('auto_product_import_debug_mode', '__return_true');

// Load the plugin class file
require_once('includes/class-auto-product-import.php');

// URL to test
$test_url = 'https://www.impactguns.com/revolvers/ruger-wrangler-22-lr-4-62-barrel-6rd-burnt-bronze-736676020041-2004';

echo "===========================================\n";
echo "STANDALONE TEST FOR AUTO PRODUCT IMPORT\n";
echo "===========================================\n\n";
echo "Testing image extraction from URL: $test_url\n\n";

// Create a new instance of the plugin class
$import = new Auto_Product_Import();

// Create a minimal custom implementation of wp_remote_get
function wp_remote_get($url, $args = array()) {
    $context_options = array(
        'http' => array(
            'timeout' => isset($args['timeout']) ? $args['timeout'] : 30,
            'header' => array(
                'User-Agent: ' . (isset($args['user-agent']) ? $args['user-agent'] : 'PHP/Standalone')
            )
        )
    );
    
    $context = stream_context_create($context_options);
    
    try {
        $response = file_get_contents($url, false, $context);
        
        if ($response === false) {
            return new WP_Error('request_failed', 'Failed to fetch the URL');
        }
        
        $status_line = $http_response_header[0];
        preg_match('{HTTP\/\S*\s(\d{3})}', $status_line, $match);
        $status_code = $match[1];
        
        return array(
            'body' => $response,
            'response' => array('code' => $status_code),
            'headers' => $http_response_header
        );
    } catch (Exception $e) {
        return new WP_Error('request_failed', $e->getMessage());
    }
}

// Minimal implementation of WP_Error
class WP_Error {
    protected $code;
    protected $message;
    
    public function __construct($code, $message) {
        $this->code = $code;
        $this->message = $message;
    }
    
    public function get_error_message() {
        return $this->message;
    }
}

// Minimal functions for remote response handling
function wp_remote_retrieve_response_code($response) {
    return isset($response['response']['code']) ? $response['response']['code'] : 0;
}

function wp_remote_retrieve_body($response) {
    return isset($response['body']) ? $response['body'] : '';
}

function is_wp_error($thing) {
    return $thing instanceof WP_Error;
}

// Modified version of the fetch_product_data_from_url method to extract only images
function extract_images_from_url($import, $url) {
    $response = wp_remote_get($url, array(
        'timeout' => 60,
        'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    ));
    
    if (is_wp_error($response)) {
        echo "Error: " . $response->get_error_message() . "\n";
        return array();
    }
    
    $response_code = wp_remote_retrieve_response_code($response);
    if ($response_code !== 200) {
        echo "Error: Failed to fetch the URL. Response code: " . $response_code . "\n";
        return array();
    }
    
    $body = wp_remote_retrieve_body($response);
    if (empty($body)) {
        echo "Error: The URL returned an empty response.\n";
        return array();
    }
    
    // Create a DOMDocument instance to parse the HTML
    $dom = new DOMDocument();
    // Suppress warnings from malformed HTML
    libxml_use_internal_errors(true);
    @$dom->loadHTML($body);
    libxml_clear_errors();
    $xpath = new DOMXPath($dom);
    
    // Use the extractProductImages method to get images
    $images = $import->extractProductImages($xpath, $url);
    
    return $images;
}

// Fix: Make the extractProductImages method public temporarily for testing
$reflectionClass = new ReflectionClass('Auto_Product_Import');
$extractProductImagesMethod = $reflectionClass->getMethod('extractProductImages');
$extractProductImagesMethod->setAccessible(true);

// Extract images
try {
    $images = $extractProductImagesMethod->invokeArgs($import, array(
        new DOMXPath(new DOMDocument()),
        $test_url
    ));
    
    echo "Error: Couldn't extract images using reflection method. Trying alternative approach.\n";
    
    // Alternative approach: Manually fetch the HTML and create XPath
    $response = wp_remote_get($test_url, array(
        'timeout' => 60,
        'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    ));
    
    if (!is_wp_error($response)) {
        $body = wp_remote_retrieve_body($response);
        
        if (!empty($body)) {
            $dom = new DOMDocument();
            libxml_use_internal_errors(true);
            @$dom->loadHTML($body);
            libxml_clear_errors();
            $xpath = new DOMXPath($dom);
            
            echo "Successfully created DOM and XPath objects from HTML.\n";
            
            // Now try to extract images
            $images = $extractProductImagesMethod->invokeArgs($import, array($xpath, $test_url));
            
            // Display results
            echo "Number of Images Found: " . count($images) . "\n\n";
            
            // Display the images
            echo "Images Found:\n";
            foreach ($images as $index => $image_url) {
                echo ($index + 1) . ". $image_url\n";
            }
        } else {
            echo "Error: Empty response body.\n";
        }
    } else {
        echo "Error: " . $response->get_error_message() . "\n";
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}

echo "\nTest completed!\n"; 