<?php
// Simple test file to check PHP execution
echo "Hello, World!\n";
echo "PHP Version: " . phpversion() . "\n";
echo "Current date: " . date('Y-m-d H:i:s') . "\n";
?> 