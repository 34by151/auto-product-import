<?php
/**
 * Simple test for getAttribute vs domGetAttribute in the Auto_Product_Import class
 */

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "Testing getAttribute vs domGetAttribute functions\n\n";

// Create a mock class based on Auto_Product_Import
class MockImportClass {
    /**
     * Safely check if a DOM element has an attribute
     * 
     * @param DOMElement|DOMNode $element The DOM element to check
     * @param string $attribute The attribute to check for
     * @return bool Whether the element has the attribute
     */
    private function domHasAttribute($element, $attribute) {
        return method_exists($element, 'hasAttribute') && $element->hasAttribute($attribute);
    }
    
    /**
     * Safely get an attribute value from a DOM element
     * 
     * @param DOMElement|DOMNode $element The DOM element
     * @param string $attribute The attribute to get
     * @return string The attribute value or empty string if not found
     */
    private function domGetAttribute($element, $attribute) {
        if (method_exists($element, 'getAttribute')) {
            return $element->getAttribute($attribute);
        }
        return '';
    }
    
    /**
     * Test direct getAttribute calls - should cause errors
     */
    public function testDirectGetAttribute($node) {
        echo "Testing direct getAttribute calls (UNSAFE):\n";
        try {
            $href = $node->getAttribute('href');
            echo "-> getAttribute('href') succeeded (unexpected)\n";
        } catch (Error $e) {
            echo "-> getAttribute('href') failed as expected: " . $e->getMessage() . "\n";
        }
        
        try {
            $style = $node->getAttribute('style');
            echo "-> getAttribute('style') succeeded (unexpected)\n";
        } catch (Error $e) {
            echo "-> getAttribute('style') failed as expected: " . $e->getMessage() . "\n";
        }
        
        try {
            $srcset = $node->getAttribute('srcset');
            echo "-> getAttribute('srcset') succeeded (unexpected)\n";
        } catch (Error $e) {
            echo "-> getAttribute('srcset') failed as expected: " . $e->getMessage() . "\n";
        }
    }
    
    /**
     * Test safe domGetAttribute calls - should NOT cause errors
     */
    public function testSafeGetAttribute($node) {
        echo "\nTesting safe domGetAttribute calls (SAFE):\n";
        try {
            $href = $this->domGetAttribute($node, 'href');
            echo "-> domGetAttribute('href') succeeded as expected\n";
        } catch (Error $e) {
            echo "-> domGetAttribute('href') failed (unexpected): " . $e->getMessage() . "\n";
        }
        
        try {
            $style = $this->domGetAttribute($node, 'style');
            echo "-> domGetAttribute('style') succeeded as expected\n";
        } catch (Error $e) {
            echo "-> domGetAttribute('style') failed (unexpected): " . $e->getMessage() . "\n";
        }
        
        try {
            $srcset = $this->domGetAttribute($node, 'srcset');
            echo "-> domGetAttribute('srcset') succeeded as expected\n";
        } catch (Error $e) {
            echo "-> domGetAttribute('srcset') failed (unexpected): " . $e->getMessage() . "\n";
        }
    }
    
    /**
     * Run the tests
     */
    public function runTests() {
        // Create a non-DOMElement node for testing
        $node = new stdClass();
        
        // Run the tests
        $this->testDirectGetAttribute($node);
        $this->testSafeGetAttribute($node);
        
        echo "\nTest completed! If 'safe' tests all succeeded and 'unsafe' tests all failed, the fix works!\n";
    }
}

// Run the tests
$mock = new MockImportClass();
$mock->runTests(); 